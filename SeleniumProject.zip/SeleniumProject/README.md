**Functionality Testing - web UI Automation end to end testing **<br> 
**Tech Stack: TestNG , Page Object Model,Selenium web Driver,BDD,Gerkhins and Extent Report **<br>
<br>
Cautions: Please use your own web or permitted web for Testing. Do not test any website that are unauthorized/ not permitted.
<br>
<br>
How to run this code:
<br>
1. Install Eclipse IDE
<br>
2. Install Eclipse plugin TestNG, Cucumber
<br>
<br>
<br>
<br>
3. add utils.java inside setup folder
<br>
package setup;
<be>
<br>
public class utils {
	<br>
		public static String webUserName = "";
	<br>
		public static String webPassword = "";
	<br>
		public static String releaseNumber = "";
	<br>
		public static String webUrl ="";
	<br>
}
<br>
3. With Examples (Please look at the codes)
