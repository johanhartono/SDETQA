package pom.pages.G2;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import pom.setup.BaseTests;

public class LocationPageG2 extends BaseTests {
	
    
	static WebDriverWait wait = new WebDriverWait(BaseTests.driver, Duration.ofSeconds(90));
	
	@FindBy(xpath = "//frame[@id='Frame1']")
	static
	WebElement iframeLocation;

	
	@FindBy(xpath = "(//input[@id='rblLocList_0'])[1]")
	static WebElement Options1;
	
	@FindBy(xpath = "//input[@type=\"submit\"]")
	static WebElement Launch;
	
	@FindBy(id = "ddlAccMonth")
	static WebElement Periods;
	
	@FindBy(id = "ddlAccYear")
	static WebElement Yr;
	
	@FindBy(id = "lblManagerI")
	static WebElement Manager;
	
	@FindBy(id = "imglogOff")
	static WebElement LogOff;
	
	public LocationPageG2(WebDriver driver) {

		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);

	}
	public void intoFrameLocation() {
		driver.switchTo().frame(iframeLocation);

	}
	public  void Options1() {
		Options1.click(); 

	}
	public  void Periods() {
		Periods.click();
		Periods.sendKeys("10");

	}
	
	public  void Yr() {
		Yr.click();
		Yr.sendKeys("2025");

	}
	
	public  void Launch() {
		Launch.click();
	}
	
	public String Manager() {
		return Manager.getText();
	}
	public void LogOff() {
		LogOff.click();
	}
}

