package pom.pages.G2;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import pom.setup.BaseTests;

public class LoginPageG2 extends BaseTests {
	
    
	static WebDriverWait wait = new WebDriverWait(BaseTests.driver, Duration.ofSeconds(90));
	
	@FindBy(xpath = "//frame[@id='Frame1']")
	WebElement iframe;
	
	@FindBy(xpath= "//input[@id='txtUserId']")
	WebElement Username;

	@FindBy(xpath= "//input[@id='txtPassword']")
	WebElement Password;
	
	
	@FindBy(id = "Button1")
	WebElement login;
	

	
	public LoginPageG2(WebDriver driver) {
		LoginPageG2.driver = driver;

		// This initElements method will create all WebElements
		PageFactory.initElements(driver, this);
	}
	
	//Switch to Frame	
	public void intoFrame() {
		driver.switchTo().frame(iframe);
	}
	// Set user name in textbox
	public void setUserName(String strUserName) {
		Username.clear();
		Username.sendKeys(strUserName);
	}

	// Set password in password textbox
	public void setPassword(String strPassword) {
		Password.clear();
		Password.sendKeys(strPassword);
	}

	// Click on login button
	public void clickLogin() {
		login.click();
		//System.out.println("Login Text: " + login.getText());
	}
	public void login(String strUserName, String strPasword) {

		// Fill user name
		this.setUserName(strUserName);

		// Fill password
		this.setPassword(strPasword);

		// Click Login button
		//this.clickLogin();
	}
	

}