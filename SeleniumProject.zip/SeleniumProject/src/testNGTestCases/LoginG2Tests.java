//Scenario: Testing Login Page to ensure user name and password entered correctly
//Handling iframe

package testNGTestCases;

import org.testng.annotations.Test;

import pom.pages.G2.LoginPageG2;
import pom.pages.G2.LocationPageG2;
import pom.setup.BaseTests;
import pom.setup.utils;

public class LoginG2Tests extends BaseTests {

	LoginPageG2 objLogin;
	LocationPageG2 objLocationPageG2;

	@Test(priority = 1, enabled = true, description = "Login using valid credentials username and password")
	public void LoginTest() throws InterruptedException {
		
		
		objLogin = new LoginPageG2(driver);
		objLogin.intoFrame();
		objLogin.login(utils.webUserName2, utils.webPassword2);
		objLogin.clickLogin();
		objLocationPageG2 = new LocationPageG2(driver);
		Thread.sleep(1500);
		objLocationPageG2.LogOff();

	}
	
	@Test(priority = 2, enabled = true, description = "Login using invalid credentials username and password")
	public void LoginTestInvalid() throws InterruptedException {
		
		int i;
		objLogin = new LoginPageG2(driver);
		objLogin.login(utils.webUserName1, utils.webPassword1);
		for ( i = 1;i<=10;i++) {
			objLogin.clickLogin();
		}
		if (i > 5) {
			System.out.println("Failure!");
		}
	}
	
	}
