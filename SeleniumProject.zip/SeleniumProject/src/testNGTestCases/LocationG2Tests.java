package testNGTestCases;

import org.testng.Assert;
import org.testng.annotations.Test;

import pom.pages.G2.LocationPageG2;
import pom.pages.G2.LoginPageG2;
import pom.setup.BaseTests;
import pom.setup.utils;

public class LocationG2Tests extends BaseTests {
	LoginPageG2 objLogin; 
	LocationPageG2 objLocationPageG2;
	
	@Test(priority = 1, enabled = true, description = "Login using valid credentials username and password")
	public void LoginTest() throws InterruptedException {
		objLogin = new LoginPageG2(driver);
		objLogin.intoFrame();
		objLogin.login(utils.webUserName2, utils.webPassword2);
		objLogin.clickLogin();
		//Thread.sleep(1500);
		}
	
	@Test(priority = 2, enabled = true, description = "Location Selections and Period Selections")
	public void LocationG2Test() throws InterruptedException {
		objLocationPageG2 = new LocationPageG2(driver);
		//objLocationPageG2.intoFrameLocation();
		objLocationPageG2.Options1();
		Thread.sleep(1500);
		Assert.assertEquals(objLocationPageG2.Manager(), "Saiful Hasibuan");
		objLocationPageG2.Periods();
		Thread.sleep(1500);
		objLocationPageG2.Yr();
		//objLocationPageG2.LogOff();
		objLocationPageG2.Launch();
	}	

	
}
