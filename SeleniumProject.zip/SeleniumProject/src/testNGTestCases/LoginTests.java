//Scenario: Testing Login Page to ensure user name and password entered correctly

package testNGTestCases;

import org.testng.annotations.Test;

import pom.pages.orangeHR.LoginPage;
import pom.setup.BaseTests;
import pom.setup.utils;

public class LoginTests extends BaseTests {

	LoginPage objLogin;

	@Test(priority = 1, enabled = true, description = "Login using valid credentials username and password")
	public void LoginTest() {
		objLogin = new LoginPage(driver);
		objLogin.login(utils.webUserName1, utils.webPassword1);
		objLogin.clickLogin();
		}



}